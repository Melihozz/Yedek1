﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using omer.Data;

namespace omer.Controllers
{
    public class KursController : Controller
    {
        private readonly ApplicationDbContext _context;

        public KursController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var kurslar = await _context.Kurslar.ToListAsync();
            return View(kurslar);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create(Kurs model)
        {
            _context.Kurslar.AddAsync(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }



        [HttpGet]//Güncelleme
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var krs = await _context.Kurslar.FindAsync(id);

            //var ogr = await _context.Ogrenciler.FirstOrDefaultAsync(o => o.OgrenciId == id);


            if (krs == null)
            {

                return NotFound();

            }

            return View(krs);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(int id, Kurs model)
        {
            if (id != model.KursId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(model);
                    await _context.SaveChangesAsync();   // güncellemenin olduğu kısım
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Kurslar.Any(o => o.KursId == model.KursId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction("Index");
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var krs = await _context.Kurslar.FindAsync(id);

            if (krs == null)
            {
                return NotFound();
            }

            return View(krs);
        }


        [HttpPost]
        public async Task<IActionResult> Delete([FromForm] int id)
        {
            var krs = await _context.Kurslar.FindAsync(id);
            if (krs == null)
            {
                return NotFound();
            }
            _context.Kurslar.Remove(krs);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

    }

}

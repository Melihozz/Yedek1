﻿namespace omer.Data
{
    public class Kurs
    {
        public int KursId { get; set; }
        public String? Baslik { get; set; }

    }
}

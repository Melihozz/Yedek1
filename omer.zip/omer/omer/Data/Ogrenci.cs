﻿using System.ComponentModel.DataAnnotations;

namespace omer.Data
{
    public class Ogrenci
    {
        //id primary key
        [Key]
        [Display(Name = "ID")]
        public int OgrenciId { get; set; }
        [Display(Name = "Öğrenci Ad")]
        public string? OgrenciAd { get; set; }
        [Display(Name = "Öğrenci Soyad")]
        public string? OgrenciSoyad { get; set; }
        [Display(Name = "Eposta")]
        public string? Eposta { get; set; }
        [Display(Name = "Telefon")]
        public string? Telefon { get; set; }


    }
}

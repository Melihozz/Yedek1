﻿using System.ComponentModel.DataAnnotations;

namespace omer.Data
{
    public class Ogrenci
    {
        //id primary key
        [Key]
        public int OgrenciId { get; set; }
        [Display(Name = "Öğrenci Ad")]
        public string? OgrenciAd { get; set; }
        public string? OgrenciSoyad { get; set; }
        public string? Eposta { get; set; }
        public string? Telefon { get; set; }


    }
}
